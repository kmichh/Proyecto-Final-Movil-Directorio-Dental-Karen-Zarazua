import 'package:flutter/material.dart';
import 'package:directorio_dental/core/theme/app_colors.dart';

// Zona de fotografías.
// Todavía no usa la cámara: por ahora solo muestra el botón para agregar
// una foto y el aviso de que aún no hay ninguna.
class PhotoPlaceholderGrid extends StatelessWidget {
  final VoidCallback onAgregarFoto;

  const PhotoPlaceholderGrid({super.key, required this.onAgregarFoto});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Aún no hay fotografías.',
          style: TextStyle(color: AppColors.textLight, fontSize: 15),
        ),
        const SizedBox(height: 10),
        SizedBox(
          width: 120,
          height: 120,
          child: InkWell(
            onTap: onAgregarFoto,
            borderRadius: BorderRadius.circular(12),
            child: Container(
              decoration: BoxDecoration(
                color: AppColors.accent,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.primary, width: 2),
              ),
              child: const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.camera_alt,
                      size: 36, color: AppColors.primaryDark),
                  SizedBox(height: 4),
                  Text(
                    'Agregar foto',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: AppColors.primaryDark,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}