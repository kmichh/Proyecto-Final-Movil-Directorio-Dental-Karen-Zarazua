import 'package:directorio_dental/features/patients/models/patient.dart';
import 'package:directorio_dental/features/treatments/models/treatment.dart';

// Listas EN MEMORIA. Empiezan vacías: todo se agrega desde la app.
// OJO: al cerrar la app se pierde lo registrado, hasta que conectemos
// la base de datos local (SQLite).
final List<Patient> pacientesDemo = [];
final List<Treatment> tratamientosDemo = [];

//Funciones de ayuda para consultar los datos ----

// Regresa los tratamientos de un paciente
List<Treatment> tratamientosDe(int patientId) {
  return tratamientosDemo.where((t) => t.patientId == patientId).toList();
}

// Regresa todos los tratamientos que siguen en proceso
List<Treatment> tratamientosEnProceso() {
  return tratamientosDemo.where((t) => t.estado == estadoEnProceso).toList();
}

// ¿El paciente tiene algún tratamiento en proceso?
bool tieneTratamientoEnProceso(int patientId) {
  return tratamientosDemo
      .any((t) => t.patientId == patientId && t.estado == estadoEnProceso);
}

// Busca un paciente por su id (regresa null si no existe)
Patient? buscarPaciente(int id) {
  for (final paciente in pacientesDemo) {
    if (paciente.id == id) {
      return paciente;
    }
  }
  return null;
}

// Genera un id nuevo para un paciente
int siguienteIdPaciente() {
  int mayor = 0;
  for (final paciente in pacientesDemo) {
    if (paciente.id > mayor) {
      mayor = paciente.id;
    }
  }
  return mayor + 1;
}

// Genera un id nuevo para un tratamiento
int siguienteIdTratamiento() {
  int mayor = 0;
  for (final tratamiento in tratamientosDemo) {
    if (tratamiento.id > mayor) {
      mayor = tratamiento.id;
    }
  }
  return mayor + 1;
}