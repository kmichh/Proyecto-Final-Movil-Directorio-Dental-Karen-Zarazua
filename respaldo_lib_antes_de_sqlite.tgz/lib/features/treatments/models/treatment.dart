// Estados posibles de un tratamiento
const String estadoEnProceso = 'En proceso';
const String estadoFinalizado = 'Finalizado';
const List<String> estadosTratamiento = [estadoEnProceso, estadoFinalizado];

// Tipos de tratamiento que aparecen en el menú desplegable
const List<String> tiposTratamiento = [
  'Limpieza',
  'Ortodoncia',
  'Extracción',
  'Endodoncia',
  'Resina',
  'Blanqueamiento',
  'Prótesis',
  'Otro',
];

class Treatment {
  final int id;
  final int patientId; // a qué paciente pertenece
  String tipo;
  String descripcion;
  int citasRealizadas;
  String estado;

  Treatment({
    required this.id,
    required this.patientId,
    required this.tipo,
    required this.descripcion,
    required this.citasRealizadas,
    required this.estado,
  });
}
