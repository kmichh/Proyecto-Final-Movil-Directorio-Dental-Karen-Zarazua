import 'package:flutter/material.dart';
import 'package:directorio_dental/core/theme/app_colors.dart';
import 'package:directorio_dental/core/widgets/responsive_center.dart';
import 'package:directorio_dental/core/widgets/section_title.dart';
import 'package:directorio_dental/data/demo_data.dart';
import 'package:directorio_dental/features/treatments/models/treatment.dart';
import 'package:directorio_dental/features/treatments/widgets/photo_placeholder_grid.dart';

// Sirve para dos cosas:
// - Registrar un tratamiento nuevo (treatment == null)
// - Ver / editar un tratamiento que ya existe
class TreatmentScreen extends StatefulWidget {
  final int patientId;
  final Treatment? treatment;

  const TreatmentScreen({super.key, required this.patientId, this.treatment});

  @override
  State<TreatmentScreen> createState() => _TreatmentScreenState();
}

class _TreatmentScreenState extends State<TreatmentScreen> {
  late String _tipo;
  late String _estado;
  late int _citas;
  late TextEditingController _descripcionController;

  bool get _esEdicion => widget.treatment != null;

  @override
  void initState() {
    super.initState();
    final Treatment? existente = widget.treatment;
    _tipo = existente?.tipo ?? tiposTratamiento.first;
    _estado = existente?.estado ?? estadoEnProceso;
    _citas = existente?.citasRealizadas ?? 1;
    _descripcionController =
        TextEditingController(text: existente?.descripcion ?? '');
  }

  @override
  void dispose() {
    _descripcionController.dispose();
    super.dispose();
  }

  void _guardar() {
    final Treatment? existente = widget.treatment;

    if (existente == null) {
      // Tratamiento nuevo
      tratamientosDemo.add(
        Treatment(
          id: siguienteIdTratamiento(),
          patientId: widget.patientId,
          tipo: _tipo,
          descripcion: _descripcionController.text.trim(),
          citasRealizadas: _citas,
          estado: _estado,
        ),
      );
    } else {
      // Tratamiento que se está editando
      existente.tipo = _tipo;
      existente.descripcion = _descripcionController.text.trim();
      existente.citasRealizadas = _citas;
      existente.estado = _estado;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Tratamiento guardado')),
    );
    Navigator.pop(context);
  }

  // Caja blanca con borde para que los menús desplegables
  // se vean igual que los campos de texto.
  Widget _cajaDropdown({required Widget child}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade400),
      ),
      child: DropdownButtonHideUnderline(child: child),
    );
  }

  @override
  Widget build(BuildContext context) {
    final paciente = buscarPaciente(widget.patientId);

    return Scaffold(
      appBar: AppBar(
        title: Text(_esEdicion ? 'Editar tratamiento' : 'Nuevo tratamiento'),
      ),
      body: ResponsiveCenter(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Paciente al que pertenece
              Card(
                child: ListTile(
                  leading: const Icon(Icons.person, color: AppColors.primary),
                  title: Text(paciente?.nombre ?? 'Paciente'),
                  subtitle: const Text('Paciente'),
                ),
              ),

              // Tipo de tratamiento
              const SectionTitle(
                icon: Icons.medical_services,
                text: 'Tipo de tratamiento',
              ),
              _cajaDropdown(
                child: DropdownButton<String>(
                  value: _tipo,
                  isExpanded: true,
                  items: tiposTratamiento.map((tipo) {
                    return DropdownMenuItem<String>(
                      value: tipo,
                      child: Text(tipo),
                    );
                  }).toList(),
                  onChanged: (nuevoValor) {
                    if (nuevoValor != null) {
                      setState(() {
                        _tipo = nuevoValor;
                      });
                    }
                  },
                ),
              ),

              // Descripción
              const SectionTitle(icon: Icons.notes, text: 'Descripción y avance'),
              TextField(
                controller: _descripcionController,
                maxLines: 4,
                decoration: const InputDecoration(
                  hintText: 'Escribe aquí qué se hizo y cómo va el tratamiento',
                ),
              ),

              // Citas
              const SectionTitle(
                icon: Icons.event_available,
                text: 'Citas realizadas',
              ),
              Card(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        iconSize: 36,
                        color: AppColors.primary,
                        icon: const Icon(Icons.remove_circle_outline),
                        onPressed: _citas > 0
                            ? () {
                                setState(() {
                                  _citas--;
                                });
                              }
                            : null,
                      ),
                      SizedBox(
                        width: 70,
                        child: Text(
                          _citas.toString(),
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 30,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      IconButton(
                        iconSize: 36,
                        color: AppColors.primary,
                        icon: const Icon(Icons.add_circle_outline),
                        onPressed: () {
                          setState(() {
                            _citas++;
                          });
                        },
                      ),
                    ],
                  ),
                ),
              ),

              // Estado
              const SectionTitle(icon: Icons.flag, text: 'Estado'),
              _cajaDropdown(
                child: DropdownButton<String>(
                  value: _estado,
                  isExpanded: true,
                  items: estadosTratamiento.map((estado) {
                    return DropdownMenuItem<String>(
                      value: estado,
                      child: Text(estado),
                    );
                  }).toList(),
                  onChanged: (nuevoValor) {
                    if (nuevoValor != null) {
                      setState(() {
                        _estado = nuevoValor;
                      });
                    }
                  },
                ),
              ),

              // Fotografías
              const SectionTitle(
                icon: Icons.photo_library,
                text: 'Fotografías del tratamiento',
              ),
              PhotoPlaceholderGrid(
                onAgregarFoto: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Próximamente: tomar foto con la cámara'),
                    ),
                  );
                },
              ),

              const SizedBox(height: 28),
              ElevatedButton.icon(
                onPressed: _guardar,
                icon: const Icon(Icons.save),
                label: const Text('Guardar tratamiento'),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}
