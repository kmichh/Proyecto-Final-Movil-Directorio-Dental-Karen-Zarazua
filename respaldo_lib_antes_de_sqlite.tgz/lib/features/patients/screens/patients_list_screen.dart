import 'package:flutter/material.dart';
import 'package:directorio_dental/core/theme/app_colors.dart';
import 'package:directorio_dental/core/widgets/dismiss_background.dart';
import 'package:directorio_dental/core/widgets/responsive_center.dart';
import 'package:directorio_dental/data/demo_data.dart';
import 'package:directorio_dental/features/patients/models/patient.dart';
import 'package:directorio_dental/features/patients/screens/patient_form_screen.dart';
import 'package:directorio_dental/features/patients/screens/patient_profile_screen.dart';
import 'package:directorio_dental/features/patients/widgets/patient_card.dart';
import 'package:directorio_dental/features/treatments/models/treatment.dart';

class PatientsListScreen extends StatefulWidget {
  const PatientsListScreen({super.key});

  @override
  State<PatientsListScreen> createState() => _PatientsListScreenState();
}

class _PatientsListScreenState extends State<PatientsListScreen> {
  final List<String> _filtros = [
    'Todos',
    'En tratamiento',
    'Sin tratamiento activo',
  ];
  String _filtroSeleccionado = 'Todos';
  String _busqueda = '';

  // Lista de pacientes ya filtrada por búsqueda y por el menú desplegable
  List<Patient> get _pacientesFiltrados {
    return pacientesDemo.where((paciente) {
      final bool coincideNombre =
          paciente.nombre.toLowerCase().contains(_busqueda.toLowerCase());
      final bool enTratamiento = tieneTratamientoEnProceso(paciente.id);

      bool coincideFiltro = true;
      if (_filtroSeleccionado == 'En tratamiento') {
        coincideFiltro = enTratamiento;
      } else if (_filtroSeleccionado == 'Sin tratamiento activo') {
        coincideFiltro = !enTratamiento;
      }

      return coincideNombre && coincideFiltro;
    }).toList();
  }

  void _eliminarPaciente(Patient paciente) {
    final int indice = pacientesDemo.indexOf(paciente);
    // También se guardan sus tratamientos por si se presiona "Deshacer"
    final List<Treatment> tratamientosBorrados = tratamientosDe(paciente.id);

    setState(() {
      pacientesDemo.remove(paciente);
      tratamientosDemo.removeWhere((t) => t.patientId == paciente.id);
    });

    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${paciente.nombre} fue eliminado'),
        action: SnackBarAction(
          label: 'DESHACER',
          onPressed: () {
            final int posicion =
                indice > pacientesDemo.length ? pacientesDemo.length : indice;
            pacientesDemo.insert(posicion, paciente);
            tratamientosDemo.addAll(tratamientosBorrados);
            if (mounted) {
              setState(() {});
            }
          },
        ),
      ),
    );
  }

  void _abrirPerfil(Patient paciente) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PatientProfileScreen(patient: paciente),
      ),
    ).then((_) {
      setState(() {});
    });
  }

  void _nuevoPaciente() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const PatientFormScreen()),
    ).then((_) {
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    final List<Patient> pacientes = _pacientesFiltrados;

    return Scaffold(
      appBar: AppBar(title: const Text('Pacientes')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _nuevoPaciente,
        icon: const Icon(Icons.person_add),
        label: const Text('Nuevo paciente'),
      ),
      body: ResponsiveCenter(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Column(
                children: [
                  // Barra de búsqueda
                  TextField(
                    onChanged: (texto) {
                      setState(() {
                        _busqueda = texto;
                      });
                    },
                    decoration: const InputDecoration(
                      hintText: 'Buscar paciente por nombre',
                      prefixIcon: Icon(Icons.search),
                    ),
                  ),
                  const SizedBox(height: 12),
                  // Menú desplegable de filtro
                  Row(
                    children: [
                      const Icon(Icons.filter_list, color: AppColors.primary),
                      const SizedBox(width: 8),
                      const Text(
                        'Mostrar:',
                        style: TextStyle(fontSize: 16),
                      ),
                      const SizedBox(width: 12),
                      DropdownButton<String>(
                        value: _filtroSeleccionado,
                        items: _filtros.map((filtro) {
                          return DropdownMenuItem<String>(
                            value: filtro,
                            child: Text(filtro),
                          );
                        }).toList(),
                        onChanged: (nuevoValor) {
                          if (nuevoValor != null) {
                            setState(() {
                              _filtroSeleccionado = nuevoValor;
                            });
                          }
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Expanded(
              child: pacientes.isEmpty
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Text(
                          pacientesDemo.isEmpty
                              ? 'Aún no hay pacientes registrados.\nToca "Nuevo paciente" para agregar al primero.'
                              : 'No se encontraron pacientes',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 16,
                            color: AppColors.textLight,
                          ),
                        ),
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 90),
                      itemCount: pacientes.length,
                      itemBuilder: (context, index) {
                        final paciente = pacientes[index];
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(16),
                            child: Dismissible(
                              key: ValueKey('paciente_${paciente.id}'),
                              direction: DismissDirection.startToEnd,
                              background: const DismissBackground(),
                              onDismissed: (direccion) =>
                                  _eliminarPaciente(paciente),
                              child: PatientCard(
                                patient: paciente,
                                onTap: () => _abrirPerfil(paciente),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}