import 'package:flutter/material.dart';
import 'package:directorio_dental/core/widgets/responsive_center.dart';
import 'package:directorio_dental/core/widgets/section_title.dart';
import 'package:directorio_dental/data/demo_data.dart';
import 'package:directorio_dental/features/patients/models/patient.dart';

// Sirve para dos cosas:
// - Registrar un paciente nuevo (patient == null)
// - Editar un paciente que ya existe
class PatientFormScreen extends StatefulWidget {
  final Patient? patient;

  const PatientFormScreen({super.key, this.patient});

  @override
  State<PatientFormScreen> createState() => _PatientFormScreenState();
}

class _PatientFormScreenState extends State<PatientFormScreen> {
  late TextEditingController _nombreController;
  late TextEditingController _edadController;
  late TextEditingController _telefonoController;
  late TextEditingController _fechaController;
  late TextEditingController _alergiasController;
  late TextEditingController _padecimientosController;
  late TextEditingController _medicamentosController;
  late TextEditingController _observacionesController;

  bool get _esEdicion => widget.patient != null;

  @override
  void initState() {
    super.initState();
    final Patient? existente = widget.patient;
    _nombreController = TextEditingController(text: existente?.nombre ?? '');
    _edadController = TextEditingController(
      text: existente == null ? '' : existente.edad.toString(),
    );
    _telefonoController =
        TextEditingController(text: existente?.telefono ?? '');
    _fechaController =
        TextEditingController(text: existente?.fechaNacimiento ?? '');
    _alergiasController =
        TextEditingController(text: existente?.alergias ?? '');
    _padecimientosController =
        TextEditingController(text: existente?.padecimientos ?? '');
    _medicamentosController =
        TextEditingController(text: existente?.medicamentos ?? '');
    _observacionesController =
        TextEditingController(text: existente?.observaciones ?? '');
  }

  @override
  void dispose() {
    _nombreController.dispose();
    _edadController.dispose();
    _telefonoController.dispose();
    _fechaController.dispose();
    _alergiasController.dispose();
    _padecimientosController.dispose();
    _medicamentosController.dispose();
    _observacionesController.dispose();
    super.dispose();
  }

  void _mostrarMensaje(String texto) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(texto)),
    );
  }

  void _guardar() {
    final String nombre = _nombreController.text.trim();
    final int? edad = int.tryParse(_edadController.text.trim());

    // Solo el nombre y la edad son obligatorios
    if (nombre.isEmpty) {
      _mostrarMensaje('Escribe el nombre del paciente');
      return;
    }
    if (edad == null || edad < 0 || edad > 120) {
      _mostrarMensaje('Escribe una edad válida');
      return;
    }

    final Patient? existente = widget.patient;

    if (existente == null) {
      // Paciente nuevo
      pacientesDemo.add(
        Patient(
          id: siguienteIdPaciente(),
          nombre: nombre,
          edad: edad,
          telefono: _telefonoController.text.trim(),
          fechaNacimiento: _fechaController.text.trim(),
          alergias: _alergiasController.text.trim(),
          padecimientos: _padecimientosController.text.trim(),
          medicamentos: _medicamentosController.text.trim(),
          observaciones: _observacionesController.text.trim(),
        ),
      );
    } else {
      // Paciente que se está editando
      existente.nombre = nombre;
      existente.edad = edad;
      existente.telefono = _telefonoController.text.trim();
      existente.fechaNacimiento = _fechaController.text.trim();
      existente.alergias = _alergiasController.text.trim();
      existente.padecimientos = _padecimientosController.text.trim();
      existente.medicamentos = _medicamentosController.text.trim();
      existente.observaciones = _observacionesController.text.trim();
    }

    _mostrarMensaje(_esEdicion ? 'Cambios guardados' : 'Paciente registrado');
    Navigator.pop(context);
  }

  // Un campo de texto con su ícono, para no repetir tanto código
  Widget _campo({
    required TextEditingController controller,
    required String etiqueta,
    required IconData icono,
    TextInputType teclado = TextInputType.text,
    int lineas = 1,
    TextCapitalization mayusculas = TextCapitalization.sentences,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: TextField(
        controller: controller,
        keyboardType: teclado,
        maxLines: lineas,
        textCapitalization: mayusculas,
        decoration: InputDecoration(
          labelText: etiqueta,
          prefixIcon: Icon(icono),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_esEdicion ? 'Editar paciente' : 'Nuevo paciente'),
      ),
      body: ResponsiveCenter(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SectionTitle(icon: Icons.badge, text: 'Datos generales'),
              _campo(
                controller: _nombreController,
                etiqueta: 'Nombre completo *',
                icono: Icons.person,
                mayusculas: TextCapitalization.words,
              ),
              _campo(
                controller: _edadController,
                etiqueta: 'Edad *',
                icono: Icons.numbers,
                teclado: TextInputType.number,
              ),
              _campo(
                controller: _telefonoController,
                etiqueta: 'Teléfono',
                icono: Icons.phone,
                teclado: TextInputType.phone,
              ),
              _campo(
                controller: _fechaController,
                etiqueta: 'Fecha de nacimiento (DD/MM/AAAA)',
                icono: Icons.cake,
                teclado: TextInputType.datetime,
              ),
              const SectionTitle(
                icon: Icons.health_and_safety,
                text: 'Salud del paciente',
              ),
              _campo(
                controller: _alergiasController,
                etiqueta: 'Alergias',
                icono: Icons.warning_amber,
              ),
              _campo(
                controller: _padecimientosController,
                etiqueta: 'Padecimientos',
                icono: Icons.favorite_border,
              ),
              _campo(
                controller: _medicamentosController,
                etiqueta: 'Medicamentos',
                icono: Icons.medication,
              ),
              _campo(
                controller: _observacionesController,
                etiqueta: 'Observaciones',
                icono: Icons.notes,
                lineas: 3,
              ),
              const SizedBox(height: 8),
              const Text(
                '* Campos obligatorios',
                style: TextStyle(fontSize: 13),
              ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: _guardar,
                icon: const Icon(Icons.save),
                label: Text(
                  _esEdicion ? 'Guardar cambios' : 'Registrar paciente',
                ),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}