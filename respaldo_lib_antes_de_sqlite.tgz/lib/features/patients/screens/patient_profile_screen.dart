import 'package:flutter/material.dart';
import 'package:directorio_dental/core/theme/app_colors.dart';
import 'package:directorio_dental/core/widgets/dismiss_background.dart';
import 'package:directorio_dental/core/widgets/responsive_center.dart';
import 'package:directorio_dental/core/widgets/section_title.dart';
import 'package:directorio_dental/data/demo_data.dart';
import 'package:directorio_dental/features/patients/models/patient.dart';
import 'package:directorio_dental/features/patients/widgets/info_row.dart';
import 'package:directorio_dental/features/treatments/models/treatment.dart';
import 'package:directorio_dental/features/treatments/screens/treatment_screen.dart';
import 'package:directorio_dental/features/treatments/widgets/photo_placeholder_grid.dart';
import 'package:directorio_dental/features/treatments/widgets/treatment_card.dart';
import 'package:directorio_dental/features/patients/screens/patient_form_screen.dart';

class PatientProfileScreen extends StatefulWidget {
  final Patient patient;

  const PatientProfileScreen({super.key, required this.patient});

  @override
  State<PatientProfileScreen> createState() => _PatientProfileScreenState();
}

class _PatientProfileScreenState extends State<PatientProfileScreen> {
  // Si "tratamiento" es null se abre el formulario para uno nuevo;
  // si trae un tratamiento, se abre para editarlo.
  void _abrirTratamiento(Treatment? tratamiento) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => TreatmentScreen(
          patientId: widget.patient.id,
          treatment: tratamiento,
        ),
      ),
    ).then((_) {
      setState(() {});
    });
  }

  void _eliminarTratamiento(Treatment tratamiento) {
    final int indice = tratamientosDemo.indexOf(tratamiento);

    setState(() {
      tratamientosDemo.remove(tratamiento);
    });

    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Tratamiento de ${tratamiento.tipo} eliminado'),
        action: SnackBarAction(
          label: 'DESHACER',
          onPressed: () {
            final int posicion =
                indice > tratamientosDemo.length ? tratamientosDemo.length : indice;
            tratamientosDemo.insert(posicion, tratamiento);
            if (mounted) {
              setState(() {});
            }
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final Patient paciente = widget.patient;
    final List<Treatment> tratamientos = tratamientosDe(paciente.id);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Expediente'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            tooltip: 'Editar paciente',
                        onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      PatientFormScreen(patient: widget.patient),
                ),
              ).then((_) {
                setState(() {});
              });
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _abrirTratamiento(null),
        icon: const Icon(Icons.add),
        label: const Text('Nuevo tratamiento'),
      ),
      body: ResponsiveCenter(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
          children: [
            // Encabezado con nombre y edad
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 36,
                      backgroundColor: AppColors.primary,
                      child: Text(
                        paciente.nombre[0],
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            paciente.nombre,
                            style: const TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: AppColors.textDark,
                            ),
                          ),
                          Text(
                            '${paciente.edad} años',
                            style: const TextStyle(
                              fontSize: 16,
                              color: AppColors.textLight,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Datos generales
            const SectionTitle(icon: Icons.badge, text: 'Datos generales'),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    InfoRow(
                      icon: Icons.phone,
                      label: 'Teléfono',
                      value: paciente.telefono,
                    ),
                    InfoRow(
                      icon: Icons.cake,
                      label: 'Fecha de nacimiento',
                      value: paciente.fechaNacimiento,
                    ),
                  ],
                ),
              ),
            ),

            // Salud
            const SectionTitle(
              icon: Icons.health_and_safety,
              text: 'Salud del paciente',
            ),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    InfoRow(
                      icon: Icons.warning_amber,
                      label: 'Alergias',
                      value: paciente.alergias,
                    ),
                    InfoRow(
                      icon: Icons.favorite_border,
                      label: 'Padecimientos',
                      value: paciente.padecimientos,
                    ),
                    InfoRow(
                      icon: Icons.medication,
                      label: 'Medicamentos',
                      value: paciente.medicamentos,
                    ),
                    InfoRow(
                      icon: Icons.notes,
                      label: 'Observaciones',
                      value: paciente.observaciones,
                    ),
                  ],
                ),
              ),
            ),

            // Historial de tratamientos
            SectionTitle(
              icon: Icons.history,
              text: 'Historial de tratamientos (${tratamientos.length})',
            ),
            if (tratamientos.isEmpty)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Text('Aún no hay tratamientos registrados.'),
                ),
              )
            else
              Column(
                children: tratamientos.map((tratamiento) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: Dismissible(
                        key: ValueKey('tratamiento_${tratamiento.id}'),
                        direction: DismissDirection.startToEnd,
                        background: const DismissBackground(),
                        onDismissed: (direccion) =>
                            _eliminarTratamiento(tratamiento),
                        child: TreatmentCard(
                          treatment: tratamiento,
                          onTap: () => _abrirTratamiento(tratamiento),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),

            // Fotografías
            const SectionTitle(
              icon: Icons.photo_library,
              text: 'Fotografías',
            ),
            PhotoPlaceholderGrid(
              onAgregarFoto: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Próximamente: tomar foto con la cámara'),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
