class Patient {
  final int id;
  String nombre;
  int edad;
  String telefono;
  String fechaNacimiento;
  String alergias;
  String padecimientos;
  String medicamentos;
  String observaciones;

  Patient({
    required this.id,
    required this.nombre,
    required this.edad,
    required this.telefono,
    required this.fechaNacimiento,
    required this.alergias,
    required this.padecimientos,
    required this.medicamentos,
    required this.observaciones,
  });
}